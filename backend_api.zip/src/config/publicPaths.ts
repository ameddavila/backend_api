// Archivo que define las rutas públicas
export const publicPaths: string[] = [
  "/auth/login",
  "/auth/register",
  "/auth/forgot-password",
  "/auth/reset-password",
];
