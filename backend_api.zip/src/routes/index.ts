import { Router } from "express";
import userModuleRoutes from "../modules/users/routes"; // Importa el índice del módulo users

const router = Router();

// Middleware global para capturar solicitudes
router.use((req, res, next) => {
  console.log(
    `[Routes Index] Solicitud recibida en: ${req.method} ${req.path}`
  );
  next();
});
router.use(
  "/users",
  (req, res, next) => {
    console.log(
      `[Routes Index] Pasando al módulo users: ${req.method} ${req.path}`
    );
    next();
  },
  userModuleRoutes
);

// Ruta de prueba
router.get("/test", (req, res) => {
  console.log(`[Test Route] GET /test`);
  res.status(200).json({ message: "Ruta de prueba funcionando" });
});

export default router;
