import { Request, Response, NextFunction } from "express";
import bcrypt from "bcrypt";
import { UserModel } from "@modules/users/models"; // Asegúrate de que el archivo exista y el modelo esté exportado correctamente
import {
  generateAccessToken,
  generateRefreshToken,
  generateCsrfToken, // Verifica que esta función exista en el archivo de rutas
  parseDuration, // Verifica que esta función exista en el archivo de rutas
} from "@utils/tokenUtils"; // Cambié "../routes" a "../utils/tokenUtils" para mayor claridad
import dotenv from "dotenv";

dotenv.config();

/**
 * Login del usuario.
 */
export const login = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      res.status(400).json({
        error: "El nombre de usuario y la contraseña son obligatorios.",
      });
      return;
    }

    // Busca al usuario en la base de datos
    const user = await UserModel.findOne({ where: { username } });
    if (!user) {
      res.status(404).json({ error: "Usuario no encontrado." });
      return;
    }

    // Verifica la contraseña
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      res.status(401).json({ error: "Contraseña incorrecta." });
      return;
    }

    // Genera tokens
    const accessToken = generateAccessToken(user.id);
    const refreshToken = generateRefreshToken(user.id);
    const csrfToken = generateCsrfToken(user.id); // Cambié para usar generateCsrfToken

    // Configuración de cookies
    const cookieOptions = {
      httpOnly: true,
      secure: process.env.COOKIE_SECURE === "true",
      sameSite: "lax" as const,
    };

    // Configuración de expiración
    const accessTokenMaxAge = parseDuration(
      process.env.JWT_ACCESS_EXPIRATION || "15m"
    );
    const refreshTokenMaxAge = parseDuration(
      process.env.JWT_REFRESH_EXPIRATION || "7d"
    );

    // Establece las cookies
    res.cookie("access_token", accessToken, {
      ...cookieOptions,
      maxAge: accessTokenMaxAge,
    });
    res.cookie("refresh_token", refreshToken, {
      ...cookieOptions,
      maxAge: refreshTokenMaxAge,
    });
    res.cookie("_csrf", csrfToken, cookieOptions);

    // Responde al cliente
    res.status(200).json({ message: "Login exitoso.", csrfToken });
  } catch (error) {
    next(error);
  }
};

/**
 * Logout del usuario.
 */
export const logout = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  try {
    // Limpia las cookies
    res.clearCookie("access_token");
    res.clearCookie("refresh_token");
    res.clearCookie("_csrf");
    res.status(200).json({ message: "Logout exitoso." });
  } catch (error) {
    next(error);
  }
};
