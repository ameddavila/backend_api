import express from "express";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import router from "./routes"; // Rutas globales con públicas y protegidas
import {
  csrfProtection,
  validateCsrfMiddleware,
} from "./middlewares/csrfMiddleware"; // Middleware CSRF
import { errorHandler } from "./middlewares/errorMiddleware"; // Middleware de manejo de errores

const app = express();

// Middleware global para registrar todas las solicitudes entrantes
app.use((req, res, next) => {
  console.log(`[App Middleware] ${req.method} ${req.path}`);
  next();
});

// Configuración de seguridad con Helmet
app.use(helmet());

// Configuración de CORS para solicitudes desde el frontend
app.use(
  cors({
    origin: process.env.FRONTEND_URL, // URL del frontend permitida
    credentials: true, // Permite envío de cookies
    allowedHeaders: ["Content-Type", "X-CSRF-Token"], // Cabeceras permitidas
  })
);

// Manejo de cookies y JSON
app.use(cookieParser()); // Parseo de cookies
app.use(express.json()); // Parseo de JSON
app.use(validateCsrfMiddleware);

// Middleware global para validar tokens CSRF protegidos
app.use(csrfProtection); // Protege las rutas protegidas automáticamente

// Configuración de rutas globales
app.use("/api", router); // Define el prefijo para todas las rutas

// Manejo de errores global
app.use(errorHandler); // Captura errores de middleware y rutas

export default app;
