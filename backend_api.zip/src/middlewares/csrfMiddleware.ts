import csurf from "csurf";
import { Request, Response, NextFunction } from "express";

// Middleware para manejar el token CSRF protegido
export const csrfProtection = csurf({
  cookie: {
    key: "_csrf",
    httpOnly: true,
    secure: process.env.COOKIE_SECURE === "true", // Solo HTTPS
    sameSite: "lax", // Protección contra ataques CSRF de sitios cruzados
  },
});

export const validateCsrfMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.log(
    `[CSRF Middleware] Token esperado en cookie: ${req.cookies._csrf}`
  );
  console.log(
    `[CSRF Middleware] Token recibido: ${
      req.headers["x-csrf-token"] || req.body._csrf
    }`
  );
  next(); // Asegúrate de que este `next()` no se omita
};

// Middleware para generar automáticamente un token CSRF público en rutas públicas
export const publicCsrfMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const csrfToken = req.csrfToken(); // Genera un token público
    res.cookie("_csrf", csrfToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    });
    console.log("[CSRF] Token público generado:", csrfToken);
    next();
  } catch (error) {
    console.error("[CSRF] Error generando el token público:", error);
    res.status(500).json({ error: "Error generando el token público" });
  }
};

// Middleware para validar el token CSRF protegido (manual)
export const validateProtectedCsrfToken = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const csrfToken = req.cookies._csrf; // Token protegido en la cookie
  const sentCsrfToken = req.headers["x-csrf-token"] || req.body._csrf; // Token enviado desde el cliente

  console.log("[CSRF] Validando token protegido:");
  console.log(`[CSRF] Token en cookie: ${csrfToken}`);
  console.log(`[CSRF] Token enviado: ${sentCsrfToken}`);

  if (!csrfToken || csrfToken !== sentCsrfToken) {
    console.error("[CSRF] Token protegido inválido o ausente.");
    res.status(403).json({ error: "Invalid CSRF token" });
    return;
  }

  console.log("[CSRF] Token protegido validado correctamente.");
  next();
};
